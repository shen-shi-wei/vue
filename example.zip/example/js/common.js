﻿(function () {
  /**
   * HTTP 请求处理
   */
  var http = Vue.prototype.$http = axios.create({
    baseURL: 'http://localhost:8890/WebService',
    timeout: 1000 * 180,
    withCredentials: true
  });
})();